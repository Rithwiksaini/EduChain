"""Bhashini-compatible translation client.

The client emits the structured payload shape expected by Bhashini inference
workflows. If credentials/endpoints are configured, it performs a real HTTPS
request. For offline classroom use, it falls back to a deterministic Hinglish
lexical transformation while preserving protected STEM terms.
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass
from typing import Any, Dict

import requests


@dataclass(frozen=True)
class BhashiniConfig:
    endpoint: str = os.getenv("BHASHINI_TRANSLATE_ENDPOINT", "https://dhruva-api.bhashini.gov.in/services/inference/pipeline")
    api_key: str | None = os.getenv("BHASHINI_API_KEY")
    source_language: str = "en"
    target_language: str = "hi"
    timeout_seconds: float = 8.0


class BhashiniClient:
    STEM_TERMS = ("Fractions", "Force", "Equations", "Molecules", "Light", "Newton", "Quadratic", "Reflection", "mass", "acceleration")
    HINGLISH = {
        "solve": "solve karo", "calculate": "calculate karo", "choose": "choose karo",
        "which": "kaunsa", "what": "kya", "is": "hai", "are": "hain", "find": "find karo",
        "answer": "answer", "using": "use karke", "given": "given", "because": "kyunki",
        "the": "the", "from": "se", "both": "dono", "sides": "sides", "step": "step",
    }

    def __init__(self, config: BhashiniConfig | None = None, session: requests.Session | None = None) -> None:
        self.config = config or BhashiniConfig()
        self.session = session or requests.Session()

    def build_payload(self, text: str) -> Dict[str, Any]:
        return {
            "pipelineTasks": [{
                "taskType": "translation",
                "config": {
                    "language": {"sourceLanguage": self.config.source_language, "targetLanguage": self.config.target_language},
                    "serviceId": os.getenv("BHASHINI_TRANSLATION_SERVICE_ID", "ai4bharat/indictrans-v2-all-gpu--t4"),
                },
            }],
            "inputData": {"input": [{"source": text}]},
        }

    def translate(self, text: str, force_offline: bool = False) -> str:
        if not text.strip():
            return ""
        if not force_offline and self.config.api_key:
            try:
                headers = {"Authorization": self.config.api_key, "Content-Type": "application/json"}
                response = self.session.post(self.config.endpoint, json=self.build_payload(text), headers=headers, timeout=self.config.timeout_seconds)
                response.raise_for_status()
                data = response.json()
                translated = self._extract_translation(data)
                if translated:
                    return self._protect_stem_terms(translated)
            except (requests.RequestException, ValueError, KeyError, TypeError):
                translated = None
        return self._offline_hinglish(text)

    def _extract_translation(self, data: Dict[str, Any]) -> str | None:
        candidates = [
            data.get("pipelineResponse", [{}])[0].get("output", [{}])[0].get("target"),
            data.get("translatedText"),
        ]
        return next((str(x) for x in candidates if x), None)

    def _offline_hinglish(self, text: str) -> str:
        protected: dict[str, str] = {}
        working = text
        for index, term in enumerate(sorted(self.STEM_TERMS, key=len, reverse=True)):
            token = f"__STEM{index}__"
            working = re.sub(re.escape(term), token, working, flags=re.IGNORECASE)
            protected[token] = term
        words = re.split(r"(\W+)", working)
        translated = "".join(self.HINGLISH.get(word.lower(), word) if word.isalpha() else word for word in words)
        for token, term in protected.items():
            translated = translated.replace(token, term)
        return translated

    @staticmethod
    def _protect_stem_terms(text: str) -> str:
        # Technical terms are intentionally retained in English for classroom precision.
        return text
