"""Printable worksheet compiler using ReportLab."""
from __future__ import annotations

from io import BytesIO
from typing import Iterable, Mapping

from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
from reportlab.lib import colors


def build_worksheet_pdf(title: str, student_name: str, rows: Iterable[Mapping[str, object]]) -> bytes:
    buffer = BytesIO()
    document = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=15 * mm, leftMargin=15 * mm, topMargin=15 * mm, bottomMargin=15 * mm)
    styles = getSampleStyleSheet()
    story = [Paragraph(title, styles["Title"]), Paragraph(f"Student: {student_name}", styles["Normal"]), Spacer(1, 8)]
    table_data = [["#", "Concept", "Question", "Difficulty", "Your Answer"]]
    for index, row in enumerate(rows, start=1):
        table_data.append([str(index), str(row.get("concept", "")), str(row.get("prompt", "")), str(row.get("difficulty", "Medium")), ""])
    table = Table(table_data, colWidths=[10 * mm, 30 * mm, 85 * mm, 25 * mm, 25 * mm], repeatRows=1)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#F0F2F6")),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
        ("TOPPADDING", (0, 0), (-1, -1), 7),
    ]))
    story.append(table)
    story.extend([Spacer(1, 10), Paragraph("Teacher notes:", styles["Heading3"]), Spacer(1, 30)])
    document.build(story)
    return buffer.getvalue()
