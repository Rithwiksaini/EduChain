"""Bayesian Knowledge Tracing state estimator.

The implementation follows standard BKT with a latent mastery probability:
P(L_t | correct) = P(L_t) (1-P(S)) / [P(L_t)(1-P(S)) + (1-P(L_t))P(G)]
P(L_t | incorrect) = P(L_t)P(S) / [P(L_t)P(S) + (1-P(L_t))(1-P(G))]
P(L_{t+1}) = P(L_t | observation) + (1-P(L_t | observation))P(T)
"""
from __future__ import annotations

from dataclasses import dataclass, field
from math import isfinite
from typing import Any, Dict, List


@dataclass(frozen=True)
class BKTParameters:
    p_l0: float = 0.35
    p_t: float = 0.15
    p_g: float = 0.20
    p_s: float = 0.10

    def __post_init__(self) -> None:
        values = (self.p_l0, self.p_t, self.p_g, self.p_s)
        if any(not isfinite(v) for v in values):
            raise ValueError("BKT parameters must be finite.")
        if not 0 <= self.p_l0 <= 1 or not 0 <= self.p_t <= 1 or not 0 <= self.p_g <= 1 or not 0 <= self.p_s <= 1:
            raise ValueError("BKT parameters must be in [0, 1].")


@dataclass
class BKTState:
    concept_id: str
    mastery_probability: float
    attempts: int = 0
    correct_attempts: int = 0
    incorrect_attempts: int = 0
    history: List[Dict[str, Any]] = field(default_factory=list)


class BKTTracker:
    def __init__(self, parameters: BKTParameters | None = None) -> None:
        self.parameters = parameters or BKTParameters()

    @staticmethod
    def _clamp(value: float, low: float = 1e-9, high: float = 1 - 1e-9) -> float:
        return max(low, min(high, value))

    def posterior_after_observation(self, prior: float, correct: bool) -> float:
        """Return P(L_t | observation) before the learning transition."""
        p = self._clamp(prior)
        if correct:
            numerator = p * (1 - self.parameters.p_s)
            denominator = numerator + (1 - p) * self.parameters.p_g
        else:
            numerator = p * self.parameters.p_s
            denominator = numerator + (1 - p) * (1 - self.parameters.p_g)
        return self._clamp(numerator / denominator)

    def update_probability(self, prior: float, correct: bool) -> tuple[float, float]:
        """Return (posterior-before-learning, next_mastery-after-learning)."""
        posterior = self.posterior_after_observation(prior, correct)
        next_mastery = posterior + (1 - posterior) * self.parameters.p_t
        return posterior, self._clamp(next_mastery)

    def update_state(self, state: BKTState, correct: bool, latency_seconds: float | None = None) -> BKTState:
        prior_mastery = state.mastery_probability
        posterior, next_mastery = self.update_probability(prior_mastery, correct)
        state.attempts += 1
        if correct:
            state.correct_attempts += 1
        else:
            state.incorrect_attempts += 1
        state.mastery_probability = next_mastery
        state.history.append({
            "attempt": state.attempts,
            "correct": correct,
            "prior_mastery": round(prior_mastery, 6),
            "posterior_observation": round(posterior, 6),
            "next_mastery": round(next_mastery, 6),
            "latency_seconds": latency_seconds,
        })
        return state

    def new_state(self, concept_id: str, initial_probability: float | None = None) -> BKTState:
        probability = self.parameters.p_l0 if initial_probability is None else self._clamp(initial_probability)
        return BKTState(concept_id=concept_id, mastery_probability=probability)

    def trajectory(self, concept_id: str, observations: List[bool]) -> BKTState:
        state = self.new_state(concept_id)
        for observation in observations:
            self.update_state(state, observation)
        return state
