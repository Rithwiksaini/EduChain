"""Tabular Q-learning policy router driven by BKT mastery and response latency."""
from __future__ import annotations

import json
import random
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Dict, Iterable, Mapping

import numpy as np


class ActionType(str, Enum):
    EASY = "easy"
    MEDIUM = "medium"
    HARD = "hard"
    VISUAL_AID = "visual_aid"
    HINGLISH_HINT = "hinglish_hint"
    PEER_MENTOR = "peer_mentor"


@dataclass(frozen=True)
class RLState:
    mastery_probability: float
    response_latency_seconds: float

    def discretize(self) -> tuple[int, int]:
        mastery_bin = int(np.digitize(self.mastery_probability, [0.40, 0.70, 0.85]))
        latency_bin = int(np.digitize(self.response_latency_seconds, [15.0, 35.0, 60.0]))
        return mastery_bin, latency_bin


@dataclass(frozen=True)
class RLAction:
    action_type: ActionType
    difficulty: str
    pacing: str
    rationale: str


class RLRouter:
    """Q-learning agent with persisted Q-table and epsilon-greedy exploration.

    The environment state is explicitly (BKT mastery bin, response latency bin).
    Rewards favor correct responses at efficient latency and penalize repeated
    struggle. The policy can be trained online from actual student outcomes.
    """
    def __init__(self, q_table_path: str | Path = "data/q_table.json", alpha: float = 0.20,
                 gamma: float = 0.90, epsilon: float = 0.10, seed: int = 42) -> None:
        if not 0 < alpha <= 1 or not 0 < gamma <= 1 or not 0 <= epsilon <= 1:
            raise ValueError("Invalid Q-learning hyperparameters.")
        self.alpha, self.gamma, self.epsilon = alpha, gamma, epsilon
        self.random = random.Random(seed)
        self.actions = list(ActionType)
        self.q_table_path = Path(q_table_path)
        self.q_table: Dict[str, Dict[str, float]] = self._load()

    def _key(self, state: RLState) -> str:
        return json.dumps(state.discretize(), separators=(",", ":"))

    def _load(self) -> Dict[str, Dict[str, float]]:
        try:
            if self.q_table_path.exists():
                payload = json.loads(self.q_table_path.read_text(encoding="utf-8"))
                return {k: {a: float(v) for a, v in values.items()} for k, values in payload.items()}
        except (OSError, ValueError, TypeError):
            return {}
        return {}

    def save(self) -> None:
        self.q_table_path.parent.mkdir(parents=True, exist_ok=True)
        self.q_table_path.write_text(json.dumps(self.q_table, indent=2), encoding="utf-8")

    def _ensure_state(self, key: str) -> None:
        self.q_table.setdefault(key, {action.value: 0.0 for action in self.actions})

    def choose_action(self, state: RLState, training: bool = True) -> ActionType:
        key = self._key(state)
        self._ensure_state(key)
        if training and self.random.random() < self.epsilon:
            return self.random.choice(self.actions)
        values = self.q_table[key]
        max_value = max(values.values())
        best = [action for action in self.actions if values[action.value] == max_value]
        return self.random.choice(best)

    def update(self, state: RLState, action: ActionType, reward: float, next_state: RLState) -> None:
        key, next_key = self._key(state), self._key(next_state)
        self._ensure_state(key)
        self._ensure_state(next_key)
        current = self.q_table[key][action.value]
        target = reward + self.gamma * max(self.q_table[next_key].values())
        self.q_table[key][action.value] = current + self.alpha * (target - current)

    @staticmethod
    def reward(correct: bool, latency_seconds: float, mastery: float) -> float:
        latency = max(1.0, latency_seconds)
        efficiency = max(-1.0, 1.0 - latency / 60.0)
        mastery_bonus = 0.5 if mastery >= 0.85 else 0.0
        return (1.5 if correct else -1.25) + 0.5 * efficiency + mastery_bonus

    def route(self, state: RLState, training: bool = False) -> RLAction:
        action = self.choose_action(state, training=training)
        p = state.mastery_probability
        latency = state.response_latency_seconds
        rationales = {
            ActionType.EASY: "Lower cognitive load while BKT mastery is developing.",
            ActionType.MEDIUM: "Practice in the learner's active mastery zone.",
            ActionType.HARD: "Stretch retrieval because estimated mastery is high.",
            ActionType.VISUAL_AID: "Use a visual representation to reduce processing load.",
            ActionType.HINGLISH_HINT: "Provide localized scaffolding while preserving technical terms.",
            ActionType.PEER_MENTOR: "Request a teacher-approved peer interaction for social scaffolding.",
        }
        if action == ActionType.EASY:
            difficulty, pacing = "Easy", "Slow"
        elif action == ActionType.MEDIUM:
            difficulty, pacing = "Medium", "Normal"
        elif action == ActionType.HARD:
            difficulty, pacing = "Hard", "Fast"
        else:
            difficulty, pacing = "Medium", "Slow" if latency > 35 else "Normal"
        rationale = f"BKT mastery={p:.2f}; latency={latency:.1f}s. {rationales[action]}"
        return RLAction(action, difficulty, pacing, rationale)

    def policy_table(self) -> list[Mapping[str, str]]:
        rows = []
        for mastery in (0.20, 0.50, 0.75, 0.90):
            for latency in (10.0, 25.0, 45.0, 70.0):
                state = RLState(mastery, latency)
                action = self.route(state, training=False)
                rows.append({"BKT mastery": f"{mastery:.2f}", "Latency": f"{latency:.0f}s", "Action": action.action_type.value, "Difficulty": action.difficulty, "Pacing": action.pacing})
        return rows
