"""Teacher-approved peer mentorship matching."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, List


@dataclass(frozen=True)
class StudentSkill:
    student_id: int
    student_name: str
    concept_id: int
    mastery_probability: float
    active: bool = True


@dataclass(frozen=True)
class PeerMatch:
    mentor_id: int
    mentor_name: str
    learner_id: int
    learner_name: str
    concept_id: int
    confidence_gap: float


class PeerMatcher:
    def __init__(self, mentor_threshold: float = 0.85, learner_threshold: float = 0.40) -> None:
        self.mentor_threshold = mentor_threshold
        self.learner_threshold = learner_threshold

    def find_matches(self, records: Iterable[StudentSkill]) -> List[PeerMatch]:
        active = [r for r in records if r.active]
        mentors = [r for r in active if r.mastery_probability > self.mentor_threshold]
        learners = [r for r in active if r.mastery_probability < self.learner_threshold]
        matches: list[PeerMatch] = []
        used: set[int] = set()
        for learner in sorted(learners, key=lambda x: x.mastery_probability):
            candidates = [m for m in mentors if m.concept_id == learner.concept_id and m.student_id != learner.student_id and m.student_id not in used]
            if not candidates:
                continue
            mentor = max(candidates, key=lambda x: x.mastery_probability)
            matches.append(PeerMatch(mentor.student_id, mentor.student_name, learner.student_id, learner.student_name, learner.concept_id, mentor.mastery_probability - learner.mastery_probability))
            used.add(mentor.student_id)
        return matches
