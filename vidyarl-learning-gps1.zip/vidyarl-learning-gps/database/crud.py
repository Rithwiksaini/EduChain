"""Transactional repository functions."""
from __future__ import annotations

import json
from typing import Optional

from sqlalchemy import desc, select
from sqlalchemy.orm import Session

from .schemas import Concept, ConceptMasteryLog, PeerMentorshipNode, Question, User


class Repository:
    def __init__(self, session: Session) -> None:
        self.session = session

    def get_user(self, user_id: int) -> Optional[User]:
        return self.session.get(User, user_id)

    def get_user_by_username(self, username: str) -> Optional[User]:
        return self.session.scalar(select(User).where(User.username == username))

    def list_concepts(self, class_level: int) -> list[Concept]:
        return list(self.session.scalars(select(Concept).where(Concept.class_level == class_level, Concept.active.is_(True)).order_by(Concept.subject, Concept.title)))

    def get_question(self, question_id: int) -> Optional[Question]:
        return self.session.get(Question, question_id)

    def questions_for_concept(self, concept_id: int, difficulty: str | None = None) -> list[Question]:
        stmt = select(Question).where(Question.concept_id == concept_id)
        if difficulty:
            stmt = stmt.where(Question.difficulty == difficulty)
        return list(self.session.scalars(stmt.order_by(Question.id)))

    def latest_mastery(self, user_id: int, concept_id: int) -> float | None:
        row = self.session.scalar(select(ConceptMasteryLog).where(ConceptMasteryLog.user_id == user_id, ConceptMasteryLog.concept_id == concept_id).order_by(desc(ConceptMasteryLog.created_at)).limit(1))
        return row.posterior_mastery if row else None

    def log_attempt(self, user_id: int, concept_id: int, prior: float, posterior: float, correct: bool, latency: float, action: str) -> ConceptMasteryLog:
        row = ConceptMasteryLog(user_id=user_id, concept_id=concept_id, prior_mastery=prior, posterior_mastery=posterior, correct=correct, latency_seconds=latency, rl_action=action)
        self.session.add(row)
        self.session.flush()
        return row

    def save_peer_match(self, mentor_id: int, learner_id: int, concept_id: int) -> PeerMentorshipNode:
        existing = self.session.scalar(select(PeerMentorshipNode).where(PeerMentorshipNode.mentor_id == mentor_id, PeerMentorshipNode.learner_id == learner_id, PeerMentorshipNode.concept_id == concept_id))
        if existing:
            return existing
        row = PeerMentorshipNode(mentor_id=mentor_id, learner_id=learner_id, concept_id=concept_id, approved=False)
        self.session.add(row)
        self.session.flush()
        return row


def seed_curriculum(session: Session) -> None:
    curriculum = [
        (6, "Mathematics", "Fractions", "Add, subtract, multiply and divide fractions.", "Easy", [
            ("What is 1/2 + 1/4?", ["1/6", "3/4", "2/6", "1/8"], "3/4", "Use a common denominator of 4."),
            ("What is 3/4 × 2?", ["3/8", "3/2", "5/4", "6/8"], "3/2", "Multiply the numerator by 2."),
        ]),
        (7, "Mathematics", "Basic Algebra", "Use variables, expressions and simple linear equations.", "Medium", [
            ("Solve x + 5 = 12.", ["5", "6", "7", "17"], "7", "Subtract 5 from both sides."),
            ("If 3x = 18, x equals?", ["3", "6", "9", "15"], "6", "Divide both sides by 3."),
        ]),
        (8, "Physics", "Light", "Understand reflection, sources of light and basic ray diagrams.", "Medium", [
            ("Which object emits its own light?", ["Moon", "Mirror", "Sun", "Book"], "Sun", "The Sun is a luminous source."),
            ("A plane mirror mainly causes what?", ["Reflection", "Evaporation", "Melting", "Diffusion"], "Reflection", "Light bounces from the mirror surface."),
        ]),
        (9, "Mathematics", "Linear Equations", "Solve equations with variables on one or both sides.", "Medium", [
            ("Solve 2x + 3 = 11.", ["2", "3", "4", "7"], "4", "Subtract 3, then divide by 2."),
            ("Solve 5x - 10 = 0.", ["-2", "0", "2", "10"], "2", "Add 10 and divide by 5."),
        ]),
        (10, "Mathematics", "Quadratic Equations", "Factor and solve quadratic equations in one variable.", "Hard", [
            ("Solve x² - 5x + 6 = 0.", ["1,6", "2,3", "-2,-3", "0,6"], "2,3", "Factor as (x-2)(x-3)=0."),
            ("The roots of x² - 9 are?", ["3 only", "-3 only", "-3 and 3", "9 and 1"], "-3 and 3", "Use difference of squares."),
        ]),
        (9, "Physics", "Newton's Laws", "Apply force, mass and acceleration to motion problems.", "Hard", [
            ("What is the SI unit of Force?", ["Joule", "Newton", "Watt", "Pascal"], "Newton", "Force is measured in Newtons (N)."),
            ("For m=2 kg and a=3 m/s², Force is?", ["5 N", "6 N", "1.5 N", "9 N"], "6 N", "F = ma = 2 × 3."),
        ]),
        (10, "Chemistry", "Chemical Bonding", "Understand how atoms form bonds and molecules.", "Hard", [
            ("A molecule of water contains?", ["H and O", "C and O", "Na and Cl", "N and H only"], "H and O", "Water is H₂O."),
            ("NaCl is commonly described as having what bond?", ["Ionic", "Metallic", "Hydrogen", "None"], "Ionic", "Sodium transfers an electron to chlorine."),
        ]),
    ]
    for class_level, subject, title, description, difficulty, questions in curriculum:
        concept = session.scalar(select(Concept).where(Concept.title == title))
        if concept is None:
            concept = Concept(class_level=class_level, subject=subject, title=title, description=description, difficulty=difficulty)
            session.add(concept)
            session.flush()
        existing = session.scalar(select(Question).where(Question.concept_id == concept.id).limit(1))
        if existing is None:
            for prompt, choices, answer, explanation in questions:
                session.add(Question(concept_id=concept.id, prompt=prompt, choices_json=json.dumps(choices), answer=answer, explanation=explanation, difficulty=difficulty))
