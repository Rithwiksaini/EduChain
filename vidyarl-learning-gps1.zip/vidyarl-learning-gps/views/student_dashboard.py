"""Low-cognitive-load student dashboard for Classes 6–10."""
from __future__ import annotations

import json
import time
from typing import Any

import streamlit as st

from core_engine.bkt_tracker import BKTTracker
from core_engine.rl_router import RLRouter, RLState
from database.crud import Repository
from database.schemas import AttemptRequest
from services.bhashini_api import BhashiniClient


def _mastery_color(p: float) -> str:
    if p < 0.40:
        return "🔴"
    if p < 0.70:
        return "🟡"
    if p < 0.85:
        return "🟢"
    return "🏆"


def render(session) -> None:
    auth = st.session_state["auth"]
    repo = Repository(session)
    class_level = int(auth.get("class_level") or 9)
    tracker = BKTTracker()
    router = RLRouter()
    translator = BhashiniClient()

    st.title(f"👋 Hi, {auth['display_name']}")
    st.caption(f"Class {class_level} · Your Learning GPS")
    concepts = repo.list_concepts(class_level)
    if not concepts:
        st.warning("No curriculum is configured for this class yet.")
        return

    cols = st.columns(min(3, len(concepts)))
    for idx, concept in enumerate(concepts):
        mastery = repo.latest_mastery(auth["user_id"], concept.id)
        mastery = 0.35 if mastery is None else mastery
        cols[idx % len(cols)].metric(f"{_mastery_color(mastery)} {concept.title}", f"{mastery:.0%}")

    concept_options = {c.title: c for c in concepts}
    selected_title = st.selectbox("🧭 Choose your next lesson", list(concept_options))
    concept = concept_options[selected_title]
    mastery = repo.latest_mastery(auth["user_id"], concept.id) or tracker.parameters.p_l0
    questions = repo.questions_for_concept(concept.id)
    if not questions:
        st.info("This lesson has no questions yet.")
        return

    state_key = f"quiz_{concept.id}"
    if state_key not in st.session_state:
        st.session_state[state_key] = {"index": 0, "started": time.monotonic(), "last_feedback": None}
    quiz = st.session_state[state_key]
    question = questions[quiz["index"] % len(questions)]
    rl_state = RLState(mastery_probability=mastery, response_latency_seconds=max(1.0, time.monotonic() - quiz["started"]))
    route = router.route(rl_state, training=False)

    st.progress(float(mastery), text=f"Estimated mastery: {mastery:.0%}")
    st.info(f"🎯 GPS suggestion: **{route.difficulty}** · **{route.pacing} pace** · {route.action_type.value}")
    st.subheader(question.prompt)
    choices = json.loads(question.choices_json)
    answer = st.radio("Pick one", choices, index=None, key=f"answer_{question.id}_{quiz['index']}")

    hint_hinglish = st.toggle("💬 Hinglish hint", value=False)
    if hint_hinglish:
        hint = translator.translate(question.explanation, force_offline=True)
        st.caption(f"Hint: {hint}")
    else:
        st.caption("Hint: Work through the problem one step at a time.")

    if st.button("Check answer", type="primary", use_container_width=True, disabled=answer is None):
        latency = max(0.1, time.monotonic() - quiz["started"])
        correct = answer == question.answer
        posterior, next_mastery = tracker.update_probability(mastery, correct)
        next_state = RLState(next_mastery, latency)
        reward = router.reward(correct, latency, next_mastery)
        router.update(rl_state, route.action_type, reward, next_state)
        router.save()
        request = AttemptRequest(user_id=auth["user_id"], concept_id=concept.id, correct=correct, latency_seconds=latency)
        repo.log_attempt(request.user_id, request.concept_id, mastery, next_mastery, correct, latency, route.action_type.value)
        quiz["last_feedback"] = {"correct": correct, "explanation": question.explanation, "mastery": next_mastery}
        quiz["index"] += 1
        quiz["started"] = time.monotonic()
        st.rerun()

    if quiz["last_feedback"]:
        feedback = quiz["last_feedback"]
        if feedback["correct"]:
            st.success(f"Correct! Your estimated mastery is now {feedback['mastery']:.0%}.")
        else:
            st.error("Not quite — let's learn from it.")
        st.write(f"**Step-by-step check:** {feedback['explanation']}")
