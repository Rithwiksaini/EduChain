"""Teacher analytics, path explanations, overrides, peer routing and worksheets."""
from __future__ import annotations

import pandas as pd
import streamlit as st
from sqlalchemy import desc, select

from core_engine.peer_matcher import PeerMatcher, StudentSkill
from core_engine.rl_router import ActionType, RLRouter, RLState
from database.crud import Repository
from database.schemas import Concept, ConceptMasteryLog, User
from services.pdf_generator import build_worksheet_pdf


def render(session) -> None:
    repo = Repository(session)
    st.title("🧑‍🏫 Teacher Cockpit")
    st.caption("Use the AI as a tracking assistant; you remain the intervention decision-maker.")
    students = list(session.scalars(select(User).where(User.role == "student", User.active.is_(True)).order_by(User.display_name)))
    concepts = list(session.scalars(select(Concept).where(Concept.active.is_(True)).order_by(Concept.class_level, Concept.title)))

    briefing = []
    for student in students:
        weak = []
        for concept in concepts:
            if student.class_level == concept.class_level:
                mastery = repo.latest_mastery(student.id, concept.id)
                if mastery is not None and mastery < 0.40:
                    weak.append((concept.title, mastery))
        if weak:
            briefing.append({"Student": student.display_name, "Class": student.class_level, "Weak spots": ", ".join(f"{c} ({p:.0%})" for c, p in weak)})
    st.subheader("🌅 Morning Briefing")
    if briefing:
        st.dataframe(pd.DataFrame(briefing), use_container_width=True, hide_index=True)
    else:
        st.success("No tracked mastery below 40% in the current class-level curriculum.")

    tab1, tab2, tab3 = st.tabs(["AI Path Sequencing Logic", "Peer Pairings", "Offline Worksheet"])
    with tab1:
        st.subheader("How BKT becomes an RL action")
        st.markdown("**BKT equations**")
        st.latex(r"P(L_t|correct)=\frac{P(L_t)(1-S)}{P(L_t)(1-S)+(1-P(L_t))G}")
        st.latex(r"P(L_t|incorrect)=\frac{P(L_t)S}{P(L_t)S+(1-P(L_t))(1-G)}")
        st.latex(r"P(L_{t+1})=P(L_t|obs)+(1-P(L_t|obs))T")
        st.write("Parameters: P(L0)=0.35, P(T)=0.15, P(G)=0.20, P(S)=0.10.")
        st.markdown("**RL state:** `(BKT mastery bin, response latency bin)` → Q-learning action. Latency bins are `<15s`, `15–35s`, `35–60s`, `>60s`; mastery bins are `<40%`, `40–70%`, `70–85%`, `>85%`.")
        router = RLRouter()
        rows = router.policy_table()
        st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
        st.subheader("Teacher override")
        student_names = {s.display_name: s for s in students}
        if student_names:
            chosen = st.selectbox("Student", list(student_names))
            forced = st.selectbox("Force next action", [a.value for a in ActionType])
            if st.button("Apply override", use_container_width=True):
                st.session_state.setdefault("teacher_overrides", {})[student_names[chosen].id] = forced
                st.success(f"Next route for {chosen} is overridden to {forced}.")

    with tab2:
        st.subheader("Teacher-approved peer mentor candidates")
        records = []
        for student in students:
            for concept in concepts:
                if student.class_level != concept.class_level:
                    continue
                mastery = repo.latest_mastery(student.id, concept.id)
                if mastery is not None:
                    records.append(StudentSkill(student.id, student.display_name, concept.id, mastery))
        matches = PeerMatcher().find_matches(records)
        if matches:
            df = pd.DataFrame([{"Mentor": m.mentor_name, "Learner": m.learner_name, "Concept ID": m.concept_id, "Mastery gap": f"{m.confidence_gap:.0%}"} for m in matches])
            st.dataframe(df, use_container_width=True, hide_index=True)
            for match in matches:
                if st.button(f"Approve {match.mentor_name} → {match.learner_name} (concept {match.concept_id})", key=f"peer_{match.mentor_id}_{match.learner_id}_{match.concept_id}"):
                    repo.save_peer_match(match.mentor_id, match.learner_id, match.concept_id).approved = True
                    session.commit()
                    st.success("Peer pairing approved.")
        else:
            st.info("No matching mentor/learner pair meets the >85% / <40% thresholds on the same concept.")

    with tab3:
        st.subheader("Generate a printable worksheet")
        if concepts:
            selected = st.multiselect("Concepts", [c.title for c in concepts], default=[concepts[0].title])
            selected_concepts = [c for c in concepts if c.title in selected]
            rows = []
            for concept in selected_concepts:
                for q in repo.questions_for_concept(concept.id)[:3]:
                    rows.append({"concept": concept.title, "prompt": q.prompt, "difficulty": q.difficulty})
            if rows:
                pdf = build_worksheet_pdf("VidyaRL Offline Practice Worksheet", "________________", rows)
                st.download_button("⬇️ Download PDF worksheet", data=pdf, file_name="vidyarl_worksheet.pdf", mime="application/pdf", use_container_width=True)
