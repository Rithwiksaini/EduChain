"""Authentication view and authorization guard."""
from __future__ import annotations

import hashlib
import hmac
import secrets

import streamlit as st
from sqlalchemy.orm import Session

from database.crud import Repository
from database.schemas import LoginRequest, User


def hash_password(password: str, salt: bytes | None = None) -> str:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 210_000)
    return f"pbkdf2_sha256$210000${salt.hex()}${digest.hex()}"


def verify_password(password: str, encoded: str) -> bool:
    try:
        algorithm, rounds, salt_hex, digest_hex = encoded.split("$", 3)
        if algorithm != "pbkdf2_sha256":
            return False
        candidate = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt_hex), int(rounds)).hex()
        return hmac.compare_digest(candidate, digest_hex)
    except (ValueError, TypeError):
        return False


def ensure_demo_accounts(session: Session) -> None:
    repo = Repository(session)
    if repo.get_user_by_username("teacher") is None:
        session.add(User(username="teacher", display_name="Demo Teacher", role="teacher", password_hash=hash_password("Teacher@123")))
    if repo.get_user_by_username("student") is None:
        session.add(User(username="student", display_name="Demo Student", role="student", class_level=9, password_hash=hash_password("Student@123")))
    session.flush()


def login_view(session: Session) -> bool:
    st.title("📚 VidyaRL — The Learning GPS")
    st.caption("Adaptive learning powered by Bayesian Knowledge Tracing + Q-learning")
    with st.form("login_form"):
        username = st.text_input("Username", autocomplete="username")
        password = st.text_input("Password", type="password", autocomplete="current-password")
        submitted = st.form_submit_button("Sign in", use_container_width=True)
    if submitted:
        try:
            request = LoginRequest(username=username, password=password)
            user = Repository(session).get_user_by_username(request.username)
            if user and user.active and verify_password(request.password, user.password_hash):
                st.session_state["auth"] = {"user_id": user.id, "role": user.role, "display_name": user.display_name, "class_level": user.class_level}
                st.rerun()
            st.error("Invalid username or password.")
        except ValueError as exc:
            st.error(str(exc))
    st.info("Demo accounts: teacher / Teacher@123 · student / Student@123")
    return False


def require_role(role: str) -> bool:
    auth = st.session_state.get("auth")
    return bool(auth and auth.get("role") == role)
